Blockly.Python['move_up'] = function(block) {
  return "py_moveUp()";
};