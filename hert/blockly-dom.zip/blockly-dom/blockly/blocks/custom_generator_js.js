Blockly.JavaScript['move_up'] = function(block) {
  return "sj_moveUp()";
};